package inheritance;

public class BaseClass 
{

	public void add()
	{
		System.out.println("Addition method from Base Class");
	}
	public void sub()
	{
		System.out.println("Subtraction method from Base Class");
	}
}
